from django.urls import path,include
from .import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.conf.urls import url



urlpatterns=[
    path('',views.index,name='ShopeHome'),
    path('about/',views.about,name='Aboutus'),
    path('contact/',views.contact,name='contactus'),
    path('tracker',views.tracker,name='Trackingstatus'),
    path('search',views.search,name='Search'),
    path('products/<int:myid>',views.products,name='search'),
    path('checkout',views.checkout,name='Checkout'),
    path("handlerequest/", views.handlerequest, name="HandleRequest"),
    path('shop/signup', views.handleSignup,name='handleSignup'),
    path('shop/logout', views.handleLogout,name='handleLogout'),
    path('shop/login', views.handleLogin,name='handleLogin'),

]
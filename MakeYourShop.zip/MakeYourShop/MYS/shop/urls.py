from django.urls import path,include
from .import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.conf.urls import url



urlpatterns=[
    path('',views.index,name='ShopeHome'),
    path('about/',views.about,name='Aboutus'),
    path('contact/',views.contact,name='contactus'),
    path('tracker',views.tracker,name='Trackingstatus'),
    path('search',views.search,name='Search'),
    path('products/<int:myid>',views.products,name='Search'),
    path('checkout',views.checkout,name='Checkout'),
    path("handlerequest/", views.handlerequest, name="HandleRequest"),

]